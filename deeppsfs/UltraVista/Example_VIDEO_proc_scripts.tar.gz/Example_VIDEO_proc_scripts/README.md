# Some scripts and configs to produce MEDS files from
# VIDEO ZYJHKs data

Notes:

1.  Need the IR data from Will Hartley.  They are available from his ftp:
ftp://ftp.star.ucl.ac.uk/whartley/VIDEO/
These data also available on NERSC: /global/cscratch1/sd/amichoi/VIDEO
(also UltraVISTA overlap with COSMOS available here: ftp://ftp.star.ucl.ac.uk/whartley/ultraVISTA)

2.  `videoproc_script.py` runs PSFEx (need SExtractor and PSFEx to be installed in one's path)

3.  `make_meds_erin_SN-C3_C28.py` makes a MEDS file based on detections from,
say, an r-band MEDS file that I got from Erin for this test field.
Erin's MEDS files for this pointing are located at:
https://www.cosmo.bnl.gov/Private/gpfs/desdata/meds/Y3A2_DEEP/SN-C3_C28_r3499p02/
However, the full updated MEDS files should be at DESDM, so a query could be
used to get those.

4.  Next step needs to be done!  This is running MOF over the MEDS files 
that one can produce for the test field in step 3.  We want forced-photometry 
based on the r-band detections;  Erin has pointed me to this config file which 
is an example of this new mode:
 https://github.com/esheldon/ngmix-y3-config/blob/master/run-y3v02-fp-Y-t001.yaml
This will have to be adapted for use for this particular case.

--Also included a script called `test_meds_and_plots.py` which I was using 
to look at some MEDS content, but is not anything special.

***************************************************
Below is random commands for running and checking things...

hdu=fits.open('SN-X3_C54_r3478p01_r.fits')
w = wcs.WCS(hdu[0].header)
astropy.wcs.utils.proj_plane_pixel_scales(w)

seems to be comparable (0.26"/pix) between the IR and optical, Will confirms
the VIDEO data were swarped to the same pixel scale to match DECam.

sex /users/PCON0003/cond0080/cats/SANDBOX/VIDEO_Ks_13_35.94_-5.28.cleaned.fits -c sex_config/default.sex -WEIGHT_IMAGE /users/PCON0003/cond0080/cats/SANDBOX/VIDEO_Ks_13_35.94_-5.28.weight.fits -CHECKIMAGE_NAME /users/PCON0003/cond0080/cats/SANDBOX/VIDEO_Ks_13_35.94_-5.28.seg.fits -CATALOG_NAME VIDEO_Ks_13_35.94_-5.28.cat -CATALOG_TYPE FITS_LDAC


Commands from Richard R.:

sex coadd/DES0157-3623_r2577p01_r.fits[0]  -c config/Y3A1_v1_sex.config  -PARAMETERS_NAME config/Y3A1_v1_sex.param_psfex  -INTERP_TYPE ALL  -DETECT_MINAREA 3  -CATALOG_TYPE FITS_LDAC  -SATUR_LEVEL 65000  -FILTER_NAME config/Y3A1_v1_sex.conv  -WEIGHT_IMAGE coadd/DES0157-3623_r2577p01_r.fits[2]  -STARNNW_NAME config/Y3A1_v1_sex.nnw  -CATALOG_NAME cat/DES0157-3623_r2577p01_r_psfcat.fits  -DETECT_THRESH 5.0

psfex cat/DES0157-3623_r2577p01_r_psfcat.fits  -c config/Y3A1_v1_psfex.config  -OUTCAT_NAME psf/DES0157-3623_r2577p01_r_psfex-starlist.fits  -XML_NAME qa/DES0157-3623_r2577p01_r_psfex.xml  -NTHREADS 8  -PSF_DIR psf

Visualizing the PSFEx files with Erin's psfex:

import psfex

row=514.25
col=610.00
pex = psfex.PSFEx(VIDEO_Ks_13_35.94_-5.28_Ks_psfcat.psf)
image = pex.get_rec(row, col)
