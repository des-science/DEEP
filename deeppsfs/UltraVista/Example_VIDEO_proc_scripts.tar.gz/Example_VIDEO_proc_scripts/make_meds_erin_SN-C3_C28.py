""" This script is similar to make_meds_SN-C3_C28.py
except that it uses Erin's MEDS files as a base
Erin's files are r3499p02 which must be a re-make of this pointing?
Seems to be just a slight update? Blinking just shows a very slight
offset/rotation

In order to get the box size, to do it in the exact same way as DES 
we would need to scamp and swarp the VIDEO images to the same frame 
and do a dual-detection SExtractor catalog to get FLUX_RADIUS.

Alternatively can do something hacky and either match the FLUX_RADIUS 
based on coordinate matching or just take the largest box_size to be 
the IR box_size
"""
import meds
import desmeds
import fitsio
import glob
import numpy as np
import esutil as eu

#filt = 'Ks'
filt = 'H'
#filt = 'J'

# Determine ra and dec extent of the following DECam deep image
r_meds_name = '/fs/scratch/cond0080/Erin_Y3A2_DEEP/\
SN-C3_C28_r3499p02_r_meds-Y3A2_DEEP.fits'
r_coadd_name = '/fs/scratch/cond0080/Erin_Y3A2_DEEP/coadd/\
/SN-C3_C28_r3499p02_r.fits'
hdu_des = meds.MEDS(r_meds_name)
des_ra = hdu_des['ra']
des_dec = hdu_des['dec']
des_id = hdu_des['id']
des_boxsize = hdu_des['box_size']

# Find the VIDEO H band images that overlap (already pared down at
# /users/PCON0003/cond0080/cats/SANDBOX/SN-C3_C28/p01/VIDEO_OVERLAP
#filt_list = glob.glob('/users/PCON0003/cond0080/cats/SANDBOX/SN-C3_C28/p01/VIDEO_OVERLAP/VIDEO_H*.cleaned.fits')
filt_list = glob.glob('/fs/scratch/cond0080/VIDEO/ftp.star.ucl.ac.uk/whartley/VIDEO/VIDEO_%s*.cleaned.fits'%filt)
print filt_list

# What is the maximum string size of the paths to H files?
IR_char_max = np.max(np.asarray(map(len, filt_list)))
nobj = des_id.size

# Make a MEDS file
IR_meds_name = r_meds_name.replace("r_meds-Y3A2", "%s_ESmeds-VIDEO"%filt)
obj_data = meds.util.get_meds_input_struct(nobj)
image_info = meds.util.get_image_info_struct(
    1+len(filt_list), IR_char_max)

obj_data['id'] = des_id
# box size is different in i and r, how is it adapted?? based on flux_radius
obj_data['box_size'] = des_boxsize  # Not sure if this will need adjustment
obj_data['ra'] = des_ra
obj_data['dec'] = des_dec

fullim_list = [r_coadd_name]+filt_list
image_info['image_path'] = fullim_list
image_info['image_ext'] = np.zeros(1+len(filt_list))
#np.zeros(len(fullim_list))
maker = meds.MEDSMaker(obj_data,
                       image_info)

maker.write(IR_meds_name)

"""
# Previous lines of code that I think are now default but left here
# for reference...probably best to ignore
for idx in range(len(filt_list)):
    hdr = fitsio.read_header(filt_list[idx])
    wcs = eu.wcsutil.WCS(hdr)
    x,y = wcs.sky2image(des_ra_cen, des_dec_cen)
    xtot, ytot = hdr['NAXIS1'], hdr['NAXIS2']
    #if (x>0)&(x<xtot)&(y>0)&(y<ytot):
    # Getting all within some proximity
    if (x>-500)&(x<xtot+500)&(y>-500)&(y<ytot+500):
        H_prox.append(filt_list[idx])
    else:
        pass

print len(H_prox)
print H_prox

# If there are more than one coadd images choose the one with
# higher weight at the given point
if len(H_prox)>1:
    for idx in range(len(H_prox)):
        wtfile = H_prox[idx].replace("cleaned", "weight")
        hdr_weight = fitsio.read_header(wtfile)
        wcs_weight = eu.wcsutil.WCS(hdr_weight)
        xloc,yloc = wcs_weight.sky2image(des_ra_cen, des_dec_cen)
        weight_data = fitsio.read(wtfile)
        H_prox_weight.append(weight_data[xloc,yloc])

print H_prox_weight
df
"""
