""" Some tests to run what's necessary to get overlapping IR data,
in this case a given VIDEO pointing in Ks band to match up with the 
MEDS files provided by DESDM for r band
"""
import meds
import sys
sys.path.append("/users/PCON0003/cond0080/src/y3-wl_image_sims/deblend")
import numpy as np
import os

filt = 'Ks'
tdir = '/users/PCON0003/cond0080/cats/SANDBOX'
#meds_r = meds.MEDS('%s/SN-X3_C54_r3478p01_r_meds-Y3A2_DEEP.fits'%tdir)
meds_r = meds.MEDS('/users/PCON0003/cond0080/cats/SANDBOX/SN-C3_C28/p01/meds/SN-C3_C28_r3478p01_r_meds-Y3A2_DEEP.fits.fz')
meds_H = meds.MEDS('/users/PCON0003/cond0080/cats/SANDBOX/SN-C3_C28/p01/meds/SN-C3_C28_r3478p01_%s_meds-VIDEO_DEEP.fits.fz'%filt)

# Read some data for cutouts
index=2000
ncutout = len(meds_H.get_cutout_list(index))
print "ncutout: ", ncutout

import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
plt.figure(figsize=(9*ncutout, 4))
for idx in range(ncutout):
    plt.subplot('1%s%s'%(str(ncutout),str(idx+1)))
    image_c = meds_H.get_cutout(index, idx)
    plt.imshow(image_c, origin='lower')
    plt.colorbar()


"""
cutout_index=0
image_r = meds_r.get_cutout(index, cutout_index)
image_H = meds_H.get_cutout(index, cutout_index+1)
image_H2 = meds_H.get_cutout(index, cutout_index+2)
image_H3 = meds_H.get_cutout(index, cutout_index+3)
imlist = meds_r.get_cutout_list(index)
"""
plt.suptitle('first cutout is r-band, the rest are VIDEO %s-band'%filt)
plt.show()

