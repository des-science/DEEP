""" Ugly serial script to process the VIDEO coadds from Will.
Current steps are as follows:
 1.  Run SExtractor and PSFEx to get .psf files
 2.  Use the ra and dec of the DECam riz detections to make MEDS
     cutouts on the IR data
 3.  Eventually run MOF, but not yet
"""
import os
import glob

def run_psf_sex(pointing):
    """ Make SExtractor cats for PSFEx to run 
    pointing should be something like VIDEO_Ks_13_35.94_-5.28
    """
    cmd = 'sex %s/%s.cleaned.fits -c %s/Y3A1_v1_sex.config \
          -PARAMETERS_NAME %s/Y3A1_v1_sex.param_psfex -INTERP_TYPE \
          ALL -DETECT_MINAREA 3 -CATALOG_TYPE FITS_LDAC  \
          -SATUR_LEVEL 65000 -FILTER_NAME %s/Y3A1_v1_sex.conv \
          -WEIGHT_IMAGE %s/%s.weight.fits -STARNNW_NAME \
          %s/Y3A1_v1_sex.nnw -CATALOG_NAME %s/%s_psfcat.fits \
          -DETECT_THRESH 5.0 -NTHREADS 20'%(
        cdir, pointing, confdir, confdir, confdir, cdir, 
        pointing, confdir, catdir, pointing)
    if os.path.exists('%s/%s_psfcat.fits'%(catdir, pointing)):
        pass
    else:
        os.system(cmd)
    
def run_psfex(pointing):
    """ Make PSFEx cats
    """
    cmd = 'psfex %s/%s_psfcat.fits -c %s/Y3A1_v1_psfex.config \
          -OUTCAT_NAME %s/%s_psfex-starlist.fits -XML_NAME \
          %s/%s_psfex.xml -NTHREADS 20 -PSF_DIR %s' %(
        catdir, pointing, confdir, psfdir, pointing, qadir, 
        pointing, psfdir)
    if os.path.exists('%s/%s_psfex-starlist.fits'%(
            psfdir, pointing)):
        pass
    else:
        os.system(cmd)


# Catalogue and script locations
# Where the coadds and weight images are
cdir = '/fs/scratch/cond0080/VIDEO/ftp.star.ucl.ac.uk/whartley/VIDEO'
# This directory
sdir = '/users/PCON0003/cond0080/scripts/deep_field_IR'
confdir = '%s/Y3A1_v1_config'%sdir
catdir = '%s/cat/'%cdir
psfdir = '%s/psf/'%cdir
qadir = '%s/qa'%cdir
# Create any of last three directories if they don't exist
if os.path.isdir(catdir):
    pass
else:
    os.system('mkdir %s'%catdir)
if os.path.isdir(psfdir):
    pass
else:
    os.system('mkdir %s'%psfdir)
if os.path.isdir(qadir):
    pass
else:
    os.system('mkdir %s'%qadir)

# Make a list of all pointings over all filters
all_list = glob.glob('%s/VIDEO_Ks_*.cleaned.fits'%cdir)

print "Total files in this directory: ", len(all_list)
for idx in range(len(all_list)):
#for idx in range(20):
    # Calculate the psfs for all the files
    # First identify the pointing
    pointing = all_list[idx].split('VIDEO/')[-1].split('.cleaned')[0]
    print pointing
    run_psf_sex(pointing)
    run_psfex(pointing)
    
# End of script
